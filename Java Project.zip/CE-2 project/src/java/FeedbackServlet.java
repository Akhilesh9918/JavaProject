import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewFeedbackServlet")
public class FeedbackServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Database connection parameters
        String url = "jdbc:derby://localhost:1527/newdb_test";
        String user = "root";
        String password = "root";
        
        try {
            // Load JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            // Establish connection
            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                // Prepare SQL statement
                String sql = "SELECT * FROM feedback";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    // Execute query
                    try (ResultSet rs = pstmt.executeQuery()) {
                        // Set response content type
                        response.setContentType("text/html");
                        // Forward ResultSet to JSP for rendering
                        request.setAttribute("rs", rs);
                        request.getRequestDispatcher("viewFeedback.jsp").forward(request, response);
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
