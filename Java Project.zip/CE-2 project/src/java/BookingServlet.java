import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String eventName = request.getParameter("eventName");
        String name = request.getParameter("name");
        String contact = request.getParameter("contact");
        String creditCard = request.getParameter("creditcard");
        String price = request.getParameter("price");
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ce2","root", "root")) {
                String query = "INSERT INTO SERVLETCLIENT (EVENTNAME, NAME, CONTACT, CREDITCARD, PRICE) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, eventName);
                pstmt.setString(2, name);
                pstmt.setString(3, contact);
                pstmt.setString(4, creditCard);
                pstmt.setString(5, price);
                
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    response.getWriter().println("<h1>Booking Successful!</h1><h2>Your Name & Number is registered Successfully</h2>");
                    // Add button to redirect to feedback form page
                    response.getWriter().println("<form action=\"feedback.jsp\">");
                    response.getWriter().println("<input type=\"submit\" value=\"See All Feedback\">");
                    response.getWriter().println("</form>");
                } else {
                    response.getWriter().println("<h1>Booking Failed!</h1>");
                }
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            e.printStackTrace(response.getWriter());
        }
    }
}
