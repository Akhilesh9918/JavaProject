import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author lenovo
 */
@Entity
public class EventEntity implements Serializable {
    @Id
    private int id;
    private String name;
    private String date;
    private String location;
    private String description;
    // getters and setters
}
