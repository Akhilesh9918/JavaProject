import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateEventServlet")
public class UpdateEventServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String eventName = request.getParameter("eventName"); 
        String date = request.getParameter("date");
        String location = request.getParameter("location");
        String description = request.getParameter("description");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ce2", "root", "root")) {
                String query = "UPDATE event SET date=?, location=?, description=? WHERE event_Name=?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, date);
                pstmt.setString(2, location);
                pstmt.setString(3, description);
                pstmt.setString(4, eventName);
                
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    response.sendRedirect("ViewEventDetails.jsp"); // Redirect to the event details page after successful update
                } else {
                    response.getWriter().println("Failed to update event."); // Show error message if update fails
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(response.getWriter());
        }
    }
}
