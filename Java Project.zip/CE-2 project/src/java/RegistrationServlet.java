import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC URL, username, and password of Derby server
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/ce2";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check if username already exists
        if (isUserExists(username)) {
            request.setAttribute("errorMessage", "Username already exists. Please choose a different username.");
            request.getRequestDispatcher("registration.jsp").forward(request, response);
        } else {
            // Create a new user
            createUser(username, password);
            response.sendRedirect("success.jsp");
        }
    }

    private boolean isUserExists(String username) {
        try {
            // Load Derby JDBC Driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            // Connect to Derby database
            try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/ce2", "root", "root")) {
                // Prepare SQL query
                String sql = "SELECT * FROM customers WHERE username = ?";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, username);

                    // Execute query
                    return statement.executeQuery().next();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void createUser(String username, String password) {
        try {
            // Load Derby JDBC Driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            // Connect to Derby database
            try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/ce2", "root", "root")) {
                // Prepare SQL query
                String sql = "INSERT INTO customers (username, password) VALUES (?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, username);
                    statement.setString(2, password);

                    // Execute query
                    statement.executeUpdate();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
