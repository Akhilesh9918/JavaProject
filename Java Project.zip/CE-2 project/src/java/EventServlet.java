import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/eventServlet")
public class EventServlet extends HttpServlet {

     // JDBC URL, username, and password of Derby server
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/ce2";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";
    // SQL queries
    private static final String INSERT_QUERY = "INSERT INTO event (event_name, date, location, description) VALUES (?, ?, ?, ?)";
    private static final String SELECT_ALL_QUERY = "SELECT * FROM event";

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve parameters from request
        String eventName = request.getParameter("name");
        String date = request.getParameter("date");
        String location = request.getParameter("location");
        String description = request.getParameter("description");

        // Establish a connection
        try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/ce2", "root", "root")) {
            // Insert event into database
            try (PreparedStatement statement = connection.prepareStatement(INSERT_QUERY)) {
                statement.setString(1, eventName);
                statement.setString(2, date);
                statement.setString(3, location);
                statement.setString(4, description);
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("A new event was inserted successfully!");
                }
            }

            // Redirect user to eventCreated.jsp with success message
            response.sendRedirect("eventCreated.jsp?message=Event+created+successfully");
        } catch (SQLException e) {
            // Handle any errors
            
        }
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Establish a connection
        try (Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/ce2", "root", "root")) {
            // Retrieve all events from database
            List<Event> events = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(SELECT_ALL_QUERY)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        Event event = new Event();
                        
                        event.setName(resultSet.getString("event_name"));
                        event.setDate(resultSet.getString("date"));
                        event.setLocation(resultSet.getString("location"));
                        event.setDescription(resultSet.getString("description"));
                        events.add(event);
                    }
                }
            }

            // Set events as attribute in request scope
            request.setAttribute("events", events);

            // Forward user to eventList.jsp to display the list of events
            request.getRequestDispatcher("eventList.jsp").forward(request, response);
        } catch (SQLException e) {
            // Handle any errors
            
        }
    }
    
}
