import java.io.IOException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GetAllEvents")
public class GetAllEventServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("eventPU");
        EntityManager em = emf.createEntityManager();

        try {
            TypedQuery<Event> query = em.createQuery("SELECT e FROM Event e", Event.class);
            List<Event> events = query.getResultList();

            request.setAttribute("events", events);
            request.getRequestDispatcher("eventlist.jsp").forward(request, response);
        } finally {
            em.close();
            emf.close();
        }
    }
}
